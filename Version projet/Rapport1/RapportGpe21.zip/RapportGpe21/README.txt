Contenu:
-Faits_élémentaires: fichier PDF contenant nos faits élémentaires
-rapport: fichier PDF contenant diverses explications sur nos choix et notre démarche
-Schema_relationnel: fichier PDF contenant notre schéma relationnel
-base:fichier texte contenant le code permettant de créer notre base de données avec une population
-basededonnee.sqlite: fichier contenant notre base de donnés
-requetesSQL: fichier texte contenant les requêtes effectuées pour tester notre base de données
-SchemaORM:fichier PDF contenant notre schéma ORM